"""
Aegis Connection Test — запустить перед деплоем
python test_connections.py
"""

import os
import asyncio
import sys

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    print("⚠️  python-dotenv не установлен: pip install python-dotenv")


async def test_redis():
    try:
        import redis
        r = redis.from_url(os.getenv("REDIS_URL", ""))
        result = r.ping()
        if result:
            r.set("aegis:test", "ok", ex=60)
            val = r.get("aegis:test")
            return True, f"PONG ✅ | R/W OK: {val}"
        return False, "Ping failed"
    except Exception as e:
        return False, str(e)


async def test_bingx():
    try:
        import aiohttp
        api_key = os.getenv("BINGX_API_KEY", "")
        demo    = os.getenv("BINGX_DEMO_MODE", "true") == "true"
        base    = "https://open-api-vst.bingx.com" if demo else "https://open-api.bingx.com"

        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{base}/openApi/swap/v2/quote/price",
                params={"symbol": "BTC-USDT"},
                headers={"X-BX-APIKEY": api_key},
                timeout=aiohttp.ClientTimeout(total=10)
            ) as resp:
                data = await resp.json()
                mode = "DEMO" if demo else "REAL"
                if resp.status == 200:
                    price = data.get("data", {}).get("price", "N/A")
                    return True, f"BTC price: ${price} [{mode}]"
                return False, f"HTTP {resp.status}: {data}"
    except Exception as e:
        return False, str(e)


async def test_telegram():
    try:
        import aiohttp
        token = os.getenv("SHORT_TELEGRAM_BOT_TOKEN") or os.getenv("TG_BOT_TOKEN", "")
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"https://api.telegram.org/bot{token}/getMe",
                timeout=aiohttp.ClientTimeout(total=10)
            ) as resp:
                data = await resp.json()
                if data.get("ok"):
                    bot = data["result"]
                    return True, f"@{bot['username']} (id: {bot['id']})"
                return False, str(data)
    except Exception as e:
        return False, str(e)


async def test_binance():
    """Проверяем доступность Binance futures API"""
    try:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://fapi.binance.com/fapi/v1/ping",
                timeout=aiohttp.ClientTimeout(total=10)
            ) as resp:
                return resp.status == 200, f"HTTP {resp.status}"
    except Exception as e:
        return False, str(e)


async def test_aegis_imports():
    """Проверяем что все Aegis модули импортируются"""
    errors = []
    modules = [
        ("aegis.signal_engine", "AegisSignalEngine"),
        ("aegis.smart_dca",     "SmartDCAEngine"),
        ("aegis.risk_manager",  "AegisRiskManager"),
        ("aegis.performance_tracker", "PerformanceTracker"),
        ("detectors.pump_detector",   "PumpDetector"),
        ("detectors.oi_analyzer",     "OIAnalyzer"),
        ("detectors.liquidation_mapper", "LiquidationMapper"),
        ("detectors.delta_analyzer",  "DeltaAnalyzer"),
    ]

    # Add src to path
    src_path = os.path.join(os.path.dirname(__file__), "src")
    if src_path not in sys.path:
        sys.path.insert(0, src_path)

    for module, cls in modules:
        try:
            mod = __import__(module, fromlist=[cls])
            getattr(mod, cls)
        except Exception as e:
            errors.append(f"{module}.{cls}: {e}")

    if errors:
        return False, "\n  ".join(errors)
    return True, f"All {len(modules)} Aegis modules OK"


async def main():
    print("\n" + "="*60)
    print("  AEGIS SHORT ALPHA — Connection & Import Tests")
    print("="*60 + "\n")

    tests = [
        ("Redis (Upstash)",  test_redis()),
        ("BingX API",        test_bingx()),
        ("Telegram Bot",     test_telegram()),
        ("Binance Futures",  test_binance()),
        ("Aegis Imports",    test_aegis_imports()),
    ]

    results = []
    for name, coro in tests:
        ok, msg = await coro
        icon = "✅" if ok else "❌"
        print(f"  {icon} {name:<20} {msg}")
        results.append(ok)

    print("\n" + "-"*60)
    passed = sum(results)
    total  = len(results)
    if passed == total:
        print(f"  🟢 ALL SYSTEMS GO! ({passed}/{total})")
        print("  → Готово к деплою на Render")
    else:
        print(f"  🔴 {total-passed} тест(а) провалилось ({passed}/{total})")
        print("  → Исправьте ошибки перед деплоем")
    print("="*60 + "\n")

    return passed == total


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
