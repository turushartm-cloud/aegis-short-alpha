# 📈 ПЛАН УЛУЧШЕНИЯ LONG БОТА
## Aegis Long Alpha v1.0 — Roadmap
### На базе liquidity-bots-main/long-bot

---

## 🎯 КОНЦЕПЦИЯ LONG БОТА

Long бот — зеркальная противоположность Short Alpha:
- **Short** ищет: перекупленность → вершину → контртренд вниз
- **Long** ищет: перепроданность → дно накопления → трендовый вход вверх

---

## 📋 ФАЗЫ УЛУЧШЕНИЯ

### ФАЗА 1 — Foundation (Приоритет: ВЫСОКИЙ)

#### 1.1 Wyckoff Accumulation Detector
**Что делает**: Находит зоны институционального накопления
```
Признаки: 
  - Selling Climax (SC) + Automatic Rally (AR)
  - Secondary Test (ST) + Spring
  - Sign of Strength (SOS) + Last Point of Support (LPS)
Сигнал LONG: Spring + объём падает → SOS + объём растёт
```

#### 1.2 Oversold Exhaustion Score
**Аналог PumpDetector для Long** — ищет дно:
```python
class DumpExhaustionDetector:
    # Z-Score < -2.5 (цена НИЖЕ VWAP - 2.5σ)
    # Volume Spike (продавцы иссякают)
    # RSI < 25 (экстремальная перепроданность)
    # → Reversal setup для LONG входа
```

#### 1.3 Buy Side Liquidity (BSL) Scanner
**Что делает**: Находит зоны где стоят стопы шортистов (BSL выше)
```
BSL кластеры:
  - Предыдущие максимумы (equal highs)
  - ОВН (Opening Market Highs)
  - Зоны Order Block сверху
→ Цена притягивается к BSL = Long target
```

---

### ФАЗА 2 — Enhanced Scoring (Приоритет: ВЫСОКИЙ)

#### 2.1 Long Signal Engine (зеркало Short)
```python
WEIGHTS_LONG = {
    'dump_exhaustion':  0.25,   # Аналог pump_detector
    'oi_funding':       0.20,   # Отрицательный funding = cheap longs
    'liquidation_map':  0.20,   # Short liq clusters ВЫШЕ
    'smc_structure':    0.25,   # CHoCH вверх + Bullish OB
    'delta_flow':       0.10,   # Bullish CVD
}

THRESHOLDS = {
    'ULTRA':    85,    # Кризисный отскок / Накопление Wyckoff
    'STRONG':   70,    # RSI < 20 + Funding < -0.05% + OI рост
    'MODERATE': 60,    # Стандартный long сетап
}
```

#### 2.2 Negative Funding Tracker
```
Funding Rate < -0.03% → лонги субсидируются шортами
Funding Rate < -0.08% → СИЛЬНЫЙ сигнал LONG
Funding Rate < -0.15% → ЭКСТРЕМАЛЬНЫЙ (шорты перегреты)
```

#### 2.3 Multi-TF Momentum (Long)
```
4h RSI > 50 + 1h RSI < 35 = коррекция в тренде = LONG
4h структура: Higher High + Higher Low = восходящий тренд
15m: CHoCH вверх + Bullish Order Block = точный вход
```

---

### ФАЗА 3 — Risk & DCA (Приоритет: СРЕДНИЙ)

#### 3.1 Long DCA Grid
```
Отличие от Short Grid:
  - Уровни DCA НИЖЕ входа (Long: усредняем при падении)
  - Larger DCA размеры при более глубоких уровнях
  - ATR-based spacing (идентично Short)
  - TP уровни ВЫШЕ входа
```

#### 3.2 Long-специфичные TP
```python
# Long TP: меньше на TP1-2 (тренд может продолжиться)
TP_WEIGHTS_LONG = [20, 20, 25, 20, 10, 5]  # Vs Short: [30, 25, 20, 13, 8, 4]
# Long = ждём большего движения, меньше фиксируем рано
```

#### 3.3 Trailing Stop (Long)
```
Активация: +1.5% прибыли (vs Short: +1.0%)
Шаг трейлинга: ATR × 0.6
Логика: Long трендовый → держим дольше
```

---

### ФАЗА 4 — BTC Correlation (Приоритет: СРЕДНИЙ)

#### 4.1 BTC Trend Filter для Long
```python
# Long бот ДОЛЖЕН торговать когда BTC растёт
if btc_change_1h > +1.0:   long_score_adj = +5  # BTC памп = бычий рынок
if btc_change_1h > +0.5:   long_score_adj = +2
if btc_change_1h < -2.0:   long_score_adj = -8  # BTC дамп = против лонга
if btc_change_1h < -1.0:   long_score_adj = -4
# Полная блокировка Long при BTC -3% за час
```

#### 4.2 ETH/BTC Ratio Signal
```
ETH/BTC растёт → альты растут → Long alt сигналы усиливаются
ETH/BTC падает → альты слабеют → осторожно с лонгами
```

---

### ФАЗА 5 — Portfolio Coordination (Приоритет: НИЗКИЙ)

#### 5.1 Short + Long Coordination Layer
```python
class PortfolioCoordinator:
    """
    Координирует Long + Short ботов через Redis.
    
    Правило: НЕ открываем Long и Short на один символ одновременно
    Правило: Суммарная экспозиция Long + Short ≤ 80% капитала
    """
    
    def check_cross_bot_conflict(self, symbol: str, direction: str) -> bool:
        short_signals = redis.get_signals("short", symbol)
        long_signals  = redis.get_signals("long", symbol)
        
        if direction == "long" and short_signals:
            return False  # Short бот уже в символе
        if direction == "short" and long_signals:
            return False  # Long бот уже в символе
        return True
```

#### 5.2 Unified Dashboard (Telegram)
```
/portfolio — общая картина всех позиций
/heat — портфельная тепловая нагрузка
/pnl — суммарный P&L Long + Short
```

---

## 🔧 КОНКРЕТНЫЕ ФАЙЛЫ ДЛЯ СОЗДАНИЯ

```
aegis-long-alpha/
├── src/
│   ├── main.py                    # Из long-bot/src/main.py + Aegis интеграция
│   ├── aegis/
│   │   ├── signal_engine_long.py  # LONG-версия (negative funding, RSI < 30)
│   │   ├── smart_dca_long.py      # DCA НИЖЕ входа (зеркало Short)
│   │   └── risk_manager.py        # ← Общий с Short (symlink)
│   └── detectors/
│       ├── dump_detector.py       # Зеркало pump_detector
│       ├── wyckoff_detector.py    # Accumulation/Distribution
│       ├── bsl_scanner.py         # Buy Side Liquidity
│       └── oi_analyzer_long.py    # Negative funding focus
```

---

## 📊 ТАРГЕТНЫЕ МЕТРИКИ LONG БОТА

| Метрика | Target | Basis |
|---------|--------|-------|
| Win Rate | 62-70% | Mean reversion от перепроданности |
| Profit Factor | ≥1.4 | Long трендовый → больше upside |
| Max Drawdown | <12% | DCA сетка амортизирует |
| Avg R/R | 1:2.5 | Трендовые движения длиннее |
| Signals/Day | 3-12 | Меньше чем Short (лонг = терпение) |

---

## ⚡ БЫСТРЫЕ УЛУЧШЕНИЯ (можно сделать прямо сейчас)

1. **MIN_LONG_SCORE = 58** (чуть мягче чем Short 60 — лонг более тренд)
2. **SCAN_INTERVAL = 240** (лонги медленнее формируются)
3. **SL_BUFFER = 3.0%** (лонг = чуть больше SL для избегания фэйк-пробоев)
4. **TP_LEVELS = [3.0, 5.0, 8.0, 12.0, 18.0, 25.0]** (лонги дальше ходят)
5. **Добавить BTC positive correlation filter**
6. **Добавить Negative Funding Rate как primary trigger**

---

## 📅 TIMELINE

| Неделя | Задача |
|--------|--------|
| 1-2 | DumpExhaustionDetector + Long Signal Engine |
| 3-4 | Wyckoff Accumulation Detector |
| 5-6 | Long DCA Grid + Risk Manager |
| 7-8 | BSL Scanner + Portfolio Coordination |
| 9   | Деплой + бэктест 2021-2024 |

---

**Статус**: Готов к разработке после стабилизации Aegis Short Alpha  
**Приоритет**: Short Alpha → Short стабилизация → Long Alpha  
**Сообщить**: "Готов к Long Alpha разработке"
