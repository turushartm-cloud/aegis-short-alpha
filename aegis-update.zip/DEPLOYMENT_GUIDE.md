# 🚀 AEGIS SHORT ALPHA — DEPLOYMENT GUIDE
## Пошаговая инструкция деплоя на Render (Paid Starter)

---

## ПРЕДВАРИТЕЛЬНЫЕ ТРЕБОВАНИЯ

Вы уже выполнили:
- [x] GitHub аккаунт + репозиторий `aegis-short-alpha` (Private)
- [x] Render аккаунт (подключён к GitHub)
- [x] Upstash Redis — сохранён `REDIS_URL`
- [x] BingX API Key + Secret (Demo Mode)
- [x] Telegram Bot Token + Chat ID

---

## ШАГ 1: ЗАГРУЗКА КОДА В GITHUB

```bash
# 1. Клонируйте ваш репозиторий
git clone https://github.com/YOUR_USERNAME/aegis-short-alpha.git
cd aegis-short-alpha

# 2. Скопируйте файлы Aegis в репозиторий
# Структура должна быть:
# aegis-short-alpha/
# ├── src/
# │   ├── main.py
# │   ├── aegis/
# │   ├── detectors/
# │   └── execution/
# ├── shared/ → symlink на liquidity-bots-main/shared
# ├── render.yaml
# ├── requirements.txt
# └── runtime.txt

# 3. Создайте symlink на shared (или скопируйте)
# ВАРИАНТ А: Symlink (если всё в одном репо)
ln -s ../liquidity-bots-main/shared shared

# ВАРИАНТ Б: Прямое копирование (рекомендуется для Render)
cp -r liquidity-bots-main/shared ./shared

# 4. Проверьте структуру
ls -la src/
# Должно быть: main.py, aegis/, detectors/, execution/, shared/

# 5. Тест импортов локально (опционально)
cd aegis-short-alpha
pip install -r requirements.txt
python test_connections.py

# 6. Commit и push
git add .
git commit -m "🔴 Aegis Short Alpha v1.0 initial deploy"
git push origin main
```

---

## ШАГ 2: ДЕПЛОЙ НА RENDER

### 2.1 Создание сервиса

```
1. Перейдите: https://dashboard.render.com
2. Нажмите "+ New" → "Web Service"
3. Подключите GitHub → выберите репозиторий aegis-short-alpha
4. Настройки:
   ┌─────────────────────────────────────────┐
   │ Name:    aegis-short-alpha              │
   │ Region:  Oregon (US West)               │
   │ Branch:  main                           │
   │ Runtime: Python 3                       │
   │ Plan:    Starter ($7/mo)  ← ВАЖНО!     │
   │                                         │
   │ Build:   pip install -r requirements.txt│
   │ Start:   uvicorn src.main:app           │
   │          --host 0.0.0.0 --port $PORT   │
   └─────────────────────────────────────────┘
```

### 2.2 Environment Variables

В Render Dashboard → Environment → Add all:

```
REDIS_URL                  = rediss://default:xxx@xxx.upstash.io:6379
BINGX_API_KEY              = your_key
BINGX_API_SECRET           = your_secret
BINGX_DEMO_MODE            = true
SHORT_TELEGRAM_BOT_TOKEN   = 1234567890:ABCxxx
SHORT_TELEGRAM_CHAT_ID     = 123456789
RENDER_EXTERNAL_URL        = https://aegis-short-alpha.onrender.com
MIN_SHORT_SCORE            = 60
SHORT_SL_BUFFER            = 2.5
SCAN_INTERVAL              = 180
MAX_PAIRS                  = 150
MAX_POSITIONS              = 15
RISK_PER_TRADE             = 0.001
MAX_POSITION_PCT           = 0.15
MAX_EXPOSURE_PCT           = 0.60
DAILY_DRAWDOWN_LIMIT       = 5.0
MAX_CONSECUTIVE_LOSSES     = 4
KELLY_FRACTION             = 0.25
ACCOUNT_CAPITAL_USD        = 1000
DCA_LEVELS                 = 4
ENABLE_AEGIS_ENGINE        = true
ENABLE_PUMP_DETECTOR       = true
ENABLE_OI_ANALYZER         = true
ENABLE_LIQ_MAPPER          = true
ENABLE_DELTA               = true
ENABLE_SMART_DCA           = true
USE_SMC                    = true
AUTO_TRADING_ENABLED       = false
```

### 2.3 Deploy

```
Нажмите "Create Web Service"
Render начнёт сборку (~3-5 минут)
Следите за логами в Deploy Logs
```

---

## ШАГ 3: ПРОВЕРКА ДЕПЛОЯ

### 3.1 Проверка здоровья

```bash
# Замените URL на ваш Render URL
export BOT_URL="https://aegis-short-alpha.onrender.com"

# Health check
curl $BOT_URL/health
# Ожидаемый ответ:
# {"status":"ok","bot":"Aegis-Short-Alpha","version":"1.0.0","aegis_engine":true}

# Status
curl $BOT_URL/status
```

### 3.2 Настройка Webhook (Telegram)

```bash
# Открыть в браузере:
https://aegis-short-alpha.onrender.com/webhook/setup

# Ожидаемый ответ:
# {"ok":true,"url":"https://aegis-short-alpha.onrender.com/webhook"}
```

### 3.3 Тест скана

```bash
curl -X POST $BOT_URL/api/scan
# Ожидаемый ответ: {"message":"Scan triggered"}
# В Telegram должны появиться сигналы через ~3-5 минут
```

---

## ШАГ 4: НАСТРОЙКА UPTIMEROBOT

```
1. https://uptimerobot.com → Add New Monitor
2. Monitor Type: HTTP(s)
3. URL: https://aegis-short-alpha.onrender.com/health
4. Interval: Every 5 minutes
5. Alert: ваш email
```

---

## ШАГ 5: НАСТРОЙКА GITHUB SECRETS (для wake workflow)

```
GitHub → Settings → Secrets and variables → Actions:

RENDER_SHORT_URL = https://aegis-short-alpha.onrender.com
RENDER_LONG_URL  = https://your-long-bot.onrender.com (если есть)
```

---

## ШАГ 6: ПЕРВЫЙ ЗАПУСК В DEMO

```
1. Убедитесь: BINGX_DEMO_MODE = true
2. Убедитесь: AUTO_TRADING_ENABLED = false (сначала только сигналы)
3. Наблюдайте сигналы в Telegram 2-3 дня
4. Проверьте качество сигналов через /api/performance
5. Если всё OK → AUTO_TRADING_ENABLED = true (в env Render)
6. После 1-2 недель demo → BINGX_DEMO_MODE = false (live)
```

---

## TELEGRAM КОМАНДЫ БОТА

```
/start     — приветствие + статус
/status    — состояние бота
/signals   — активные сигналы
/pause     — пауза сканирования
/resume    — возобновление
/scan      — запустить скан вручную

# Новые команды Aegis:
/risk      — статус риск-менеджера (CB, PnL, Kelly)
/perf      — P&L статистика за 7 дней
/dca BTC   — DCA сетка для символа
/reset     — сброс circuit breaker (после серии стопов)
```

---

## TROUBLESHOOTING

### "Module not found: aegis"
```bash
# В render.yaml убедитесь что startCommand:
uvicorn src.main:app --host 0.0.0.0 --port $PORT

# Не:
uvicorn main:app --host 0.0.0.0 --port $PORT
```

### "shared path not found"
```bash
# Убедитесь что shared/ скопирован (не symlink)
# В репозитории должна быть папка shared/ рядом с src/
ls aegis-short-alpha/
# → render.yaml, requirements.txt, runtime.txt, src/, shared/
```

### "Redis connection refused"
```bash
# 1. Используйте rediss:// (с двойным S и SSL)
# 2. Проверьте REDIS_URL полностью скопирован
# 3. Upstash регион: us-east-1 совместим с Render Oregon
```

### "BingX 401 Unauthorized"
```bash
# 1. Проверьте что BINGX_DEMO_MODE совпадает с режимом ключа
# 2. Demo API: open-api-vst.bingx.com
# 3. Real API: open-api.bingx.com
```

### Circuit Breaker сработал
```bash
# В Telegram: /reset
# Или через API:
curl -X POST $BOT_URL/api/circuit-breaker/reset
```

---

## 📊 МОНИТОРИНГ

| Endpoint | Описание |
|----------|---------|
| GET /health | Статус сервиса |
| GET /status | Полный статус + конфиг |
| GET /api/signals | Активные сигналы |
| GET /api/performance | P&L статистика |
| GET /api/risk | Risk Manager статус |
| GET /api/positions | Открытые позиции |

---

**Версия**: 1.0  
**Дата**: 20.04.2026  
**Следующий шаг**: Загрузить код → Деплоить → /webhook/setup → Наблюдать сигналы
